# segment_check.py

import numpy as np
import pandas as pd

# ---- Re-create the data with segment labels (same seed and shuffle as generate_data.py) ----
np.random.seed(42)
typical = np.random.lognormal(mean=np.log(1000), sigma=0.55, size=880)
premium = np.random.lognormal(mean=np.log(3500), sigma=0.60, size=120)
amounts = np.concatenate([typical, premium])
label   = np.array([0] * 880 + [1] * 120)        
order   = np.arange(1000)
np.random.shuffle(order)                         
amounts = np.round(amounts[order], 2)
label   = label[order]

# ---- Sanity check against the CSV  ----
raw  = pd.read_csv("order_amounts_raw.csv").iloc[:1000]["Order_Amount"].to_numpy()
ok   = ~np.isnan(raw) & (raw != -500.0)
assert np.allclose(raw[ok], amounts[ok]), "Regenerated data does not match the CSV"
print("Regenerated orders match the CSV.")

# ---- Threshold from the cleaned data, exactly as in analyze.py ----
df = pd.read_csv("order_amounts_raw.csv").drop_duplicates()
df = df[df["Order_Amount"].isna() | (df["Order_Amount"] >= 0)]
x = df["Order_Amount"].fillna(df["Order_Amount"].median()).to_numpy()
median = np.median(x)
mad    = np.median(np.abs(x - median))
thr    = median + 3.5 * mad / 0.6745
flag   = amounts > thr

print(f"Robust-z threshold            : Rs {thr:,.2f}")
print(f"Premium share of orders       : {label.mean() * 100:.0f}%")
print(f"Premium share of revenue      : {amounts[label == 1].sum() / amounts.sum() * 100:.1f}%")
print(f"Flagged orders                : {flag.sum()} "
      f"(premium {int((flag & (label == 1)).sum())}, typical {int((flag & (label == 0)).sum())})")
print(f"Premium orders NOT flagged    : {int(((~flag) & (label == 1)).sum())} of {int((label == 1).sum())}")
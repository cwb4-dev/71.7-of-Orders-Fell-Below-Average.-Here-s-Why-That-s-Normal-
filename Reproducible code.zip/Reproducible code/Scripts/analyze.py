# analyze.py
# =============================================================
# Univariate analysis of synthetic e-commerce Order_Amount data.
# Input   : order_amounts_raw.csv  (create it with generate_data.py)
# Outputs : fig_*.png, summary.json, console report
# =============================================================
import json
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import (
    skew, kurtosis, shapiro, probplot, ttest_1samp, yeojohnson, norm
)

sns.set_style("whitegrid")
np.random.seed(42)

# =============================================================
# STEP 1 — DATA HEALTH CHECK & CLEANING
# =============================================================
df = pd.read_csv("order_amounts_raw.csv")
print("\n" + "=" * 60)
print("STEP 1 — DATA HEALTH CHECK")
print("=" * 60)

print(f"Rows: {len(df)}")
print(f"Missing values: {df['Order_Amount'].isna().sum()}")
print(f"Duplicate rows: {df.duplicated().sum()}")
print(f"Negative values: {(df['Order_Amount'] < 0).sum()}")
print(f"Impossible (>₹1,00,000): {(df['Order_Amount'] > 100000).sum()}")

# Cleaning decisions
df_clean = df.drop_duplicates().copy()
df_clean = df_clean[df_clean["Order_Amount"].isna() |
                    (df_clean["Order_Amount"] >= 0)]

# Step 1b — Median imputation (robust to the right-skewed high-value tail)
median_imputed = df_clean["Order_Amount"].median()
df_clean["Order_Amount"] = df_clean["Order_Amount"].fillna(median_imputed)

# With several columns, MICE-style imputation (sklearn's IterativeImputer) is the usual next step.

x = df_clean["Order_Amount"].to_numpy()
n = len(x)
print(f"\nAfter cleaning: {n} valid rows")
print(f"Median used for imputation: ₹{median_imputed:.2f}")

# =============================================================
# STEP 2 — BASIC DESCRIPTIVE STATISTICS
# =============================================================
print("\n" + "=" * 60)
print("STEP 2 — DESCRIPTIVE STATISTICS")
print("=" * 60)
desc = {
    "Mean":   np.mean(x),
    "Median": np.median(x),
    "Mode":   stats.mode(x, keepdims=False).mode,
    "Min":    np.min(x),
    "Max":    np.max(x),
    "Std":    np.std(x, ddof=1),
    "Q1":     np.percentile(x, 25),
    "Q3":     np.percentile(x, 75),
}
for k, v in desc.items():
    print(f"{k:>7}: ₹{v:,.2f}" if isinstance(v, (int, float, np.floating))
          else f"{k:>7}: {v}")

mean, median = desc["Mean"], desc["Median"]
print(f"\nMean > Median by ₹{mean - median:,.2f}  →  right-skew signal.")

# =============================================================
# STEP 3 — SHAPE METRICS (SKEWNESS & KURTOSIS)
# =============================================================
print("\n" + "=" * 60)
print("STEP 3 — SHAPE METRICS")
print("=" * 60)
sk = skew(x)
ku = kurtosis(x, fisher=True)
print(f"Skewness        : {sk:.3f}   (>1 = highly right-skewed)")
print(f"Excess Kurtosis : {ku:.3f}   (>0 = heavy tails)")

# =============================================================
# STEP 4 — ROBUST SPREAD + ROBUST Z + EXTENDED DIAGNOSTICS
# =============================================================
print("\n" + "=" * 60)
print("STEP 4 — ROBUST SPREAD")
print("=" * 60)
mad     = np.median(np.abs(x - median))
q1, q3  = np.percentile(x, [25, 75])
iqr     = q3 - q1
trimmed = stats.trim_mean(x, proportiontocut=0.10)
cv      = (np.std(x, ddof=1) / mean) * 100

print(f"MAD                : ₹{mad:,.2f}")
print(f"IQR                : ₹{iqr:,.2f}   (Q1=₹{q1:,.2f} → Q3=₹{q3:,.2f})")
print(f"10% Trimmed Mean   : ₹{trimmed:,.2f}")
print(f"Coeff. of Variation: {cv:.1f}%")

# Step 4b — Robust (modified) Z-score
robust_z      = 0.6745 * (x - median) / mad
outlier_mask  = np.abs(robust_z) > 3.5
print(f"Robust Z-score outliers (|z|>3.5): {outlier_mask.sum()} order(s)")
print(f"Max robust Z-score: {robust_z.max():.2f}")

# Step 4c — Extended diagnostics
print("\n--- Extended diagnostics ---")
robust_z_upper = median + 3.5 * mad / 0.6745
fence          = q3 + 1.5 * iqr
print(f"Robust-z upper threshold       : ₹{robust_z_upper:,.2f}")
print(f"Tukey fence (Q3 + 1.5·IQR)     : ₹{fence:,.2f}")
print(f"Orders beyond Tukey fence      : {(x > fence).sum()}")
print(f"Share of orders below mean     : {(x < mean).mean() * 100:.1f}%")
print(f"Orders equal to median (imputed): {(x == median).sum()}")
print(f"Orders above ₹10,000           : {(x > 10000).sum()}")
print(f"Max / median ratio             : {x.max() / median:.1f}x")

xs_desc = np.sort(x)[::-1]
for p in (0.10, 0.20):
    k = int(n * p)
    share = xs_desc[:k].sum() / xs_desc.sum() * 100
    print(f"Top {int(p * 100)}% of orders ({k}) account for {share:.1f}% of revenue")

print(f"Normal curve with same mean/SD implies "
      f"{norm.cdf(0, mean, np.std(x, ddof=1)) * 100:.1f}% below ₹0 "
      f"(impossible → confirms non-normality)")

# =============================================================
# STEP 5 — VISUAL EXPLORATION
# =============================================================
print("\n" + "=" * 60)
print("STEP 5 — VISUAL EXPLORATION (saving plots)")
print("=" * 60)

# 5a. Histogram + KDE
fig, ax = plt.subplots(figsize=(9, 5))
sns.histplot(x, bins=60, kde=True, color="#4C72B0",
             edgecolor="white", linewidth=0.5, ax=ax)
ax.axvline(mean,   color="red",   ls="--", label=f"Mean ₹{mean:,.0f}")
ax.axvline(median, color="green", ls="--", label=f"Median ₹{median:,.0f}")
ax.set_title("Order Amount — Histogram + KDE")
ax.set_xlabel("Order Amount (₹)")
ax.legend()
plt.tight_layout(); plt.savefig("fig_hist_kde.png", dpi=120); plt.close()

# 5b. Box plot
fig, ax = plt.subplots(figsize=(9, 2.8))
sns.boxplot(x=x, color="#55A868", ax=ax)
ax.set_title("Order Amount — Box Plot (outliers visible)")
ax.set_xlabel("Order Amount (₹)")
plt.tight_layout(); plt.savefig("fig_boxplot.png", dpi=120); plt.close()

# 5c. ECDF
xs   = np.sort(x)
ecdf = np.arange(1, len(xs) + 1) / len(xs)
fig, ax = plt.subplots(figsize=(9, 5))
ax.plot(xs, ecdf, color="#C44E52", lw=2)
ax.axhline(0.85, color="gray", ls=":", label="85% line")
ax.axvline(2000, color="gray", ls=":", label="₹2,000")
ax.set_title("ECDF — Cumulative Distribution of Order Amounts")
ax.set_xlabel("Order Amount (₹)"); ax.set_ylabel("Cumulative Probability")
ax.legend()
plt.tight_layout(); plt.savefig("fig_ecdf.png", dpi=120); plt.close()

pct_under_2000 = (x < 2000).mean() * 100
print(f"ECDF insight: {pct_under_2000:.1f}% of orders are under ₹2,000")

# 5d. PDF vs KDE
fig, ax = plt.subplots(figsize=(9, 5))
sns.kdeplot(x, ax=ax, color="#4C72B0", lw=2, label="KDE (empirical)")
shape, loc, scale = stats.lognorm.fit(x, floc=0)
xx = np.linspace(0, np.percentile(x, 99.5), 400)
ax.plot(xx, stats.lognorm.pdf(xx, shape, loc, scale),
        color="orange", ls="--", label="Fitted Lognormal PDF")
ax.set_title("PDF (theoretical) vs KDE (empirical)")
ax.set_xlabel("Order Amount (₹)"); ax.legend()
plt.tight_layout(); plt.savefig("fig_pdf_vs_kde.png", dpi=120); plt.close()

# =============================================================
# STEP 6 — NORMALITY TESTING
# =============================================================
print("\n" + "=" * 60)
print("STEP 6 — NORMALITY TESTING")
print("=" * 60)

fig, ax = plt.subplots(figsize=(6, 6))
probplot(x, dist="norm", plot=ax)
ax.set_title("Q-Q Plot — Original Order Amounts")
plt.tight_layout(); plt.savefig("fig_qq_before.png", dpi=120); plt.close()

sw_stat, sw_p = shapiro(x)
print(f"Shapiro-Wilk statistic: {sw_stat:.4f}")
print(f"Shapiro-Wilk p-value  : {sw_p:.3e}   → "
      f"{'NON-normal' if sw_p < 0.05 else 'normal'}")

# =============================================================
# STEP 7 — POWER TRANSFORMATION (Yeo-Johnson)
# =============================================================
print("\n" + "=" * 60)
print("STEP 7 — YEO-JOHNSON TRANSFORMATION")
print("=" * 60)
x_yj, lam = yeojohnson(x)
print(f"Yeo-Johnson lambda : {lam:.3f}")
print(f"Skewness before    : {skew(x):.3f}")
print(f"Skewness after     : {skew(x_yj):.3f}")
sw_yj_p = shapiro(x_yj).pvalue
print(f"Shapiro-Wilk after : p = {sw_yj_p:.3f}")

fig, ax = plt.subplots(figsize=(6, 6))
probplot(x_yj, dist="norm", plot=ax)
ax.set_title("Q-Q Plot — After Yeo-Johnson")
plt.tight_layout(); plt.savefig("fig_qq_after.png", dpi=120); plt.close()

# =============================================================
# STEP 8 — CLT & CONFIDENCE INTERVAL
# =============================================================
print("\n" + "=" * 60)
print("STEP 8 — CLT & 95% CONFIDENCE INTERVAL")
print("=" * 60)

n_samples   = 1000
sample_size = 50
sample_means = np.array([
    np.mean(np.random.choice(x, size=sample_size, replace=False))
    for _ in range(n_samples)
])

fig, ax = plt.subplots(figsize=(9, 5))
sns.histplot(sample_means, bins=40, kde=True, color="#8172B2",
             edgecolor="white", ax=ax)
ax.set_title(f"Sampling Distribution of the Mean (n={sample_size}, "
             f"{n_samples} trials)")
ax.set_xlabel("Sample Mean (₹)")
plt.tight_layout(); plt.savefig("fig_clt.png", dpi=120); plt.close()

se           = np.std(x, ddof=1) / np.sqrt(n)
ci_lo, ci_hi = mean - 1.96 * se, mean + 1.96 * se
print(f"Sample mean          : ₹{mean:,.2f}")
print(f"Standard error       : ₹{se:,.2f}")
print(f"95% CI for the mean  : [₹{ci_lo:,.2f}, ₹{ci_hi:,.2f}]")

# CLT diagnostics (note: samples are drawn WITHOUT replacement from 999 orders,
# so the exact SD is slightly below sigma/sqrt(50); see the finite-population correction)
print(f"Sample means (n=50)  : skew {skew(sample_means):.2f}, "
      f"mean {sample_means.mean():,.0f}, "
      f"sd {sample_means.std(ddof=1):,.0f}, "
      f"theory σ/√50 {np.std(x, ddof=1) / np.sqrt(sample_size):,.0f}")

# =============================================================
# STEP 9 — BOOTSTRAP CI FOR THE MEDIAN
# =============================================================
print("\n" + "=" * 60)
print("STEP 9 — BOOTSTRAP CI (MEDIAN)")
print("=" * 60)
B = 10_000
boot_medians = np.array([
    np.median(np.random.choice(x, size=n, replace=True))
    for _ in range(B)
])
boot_lo, boot_hi = np.percentile(boot_medians, [2.5, 97.5])
print(f"Bootstrap median       : ₹{np.mean(boot_medians):,.2f}")
print(f"95% Bootstrap CI       : [₹{boot_lo:,.2f}, ₹{boot_hi:,.2f}]")
print(f"Compare CLT CI on mean : [₹{ci_lo:,.2f}, ₹{ci_hi:,.2f}]")

# =============================================================
# STEP 10 — ONE-SAMPLE T-TEST + COHEN'S d
# =============================================================
print("\n" + "=" * 60)
print("STEP 10 — ONE-SAMPLE T-TEST vs ₹1,350 BENCHMARK")
print("=" * 60)
mu0 = 1350.0
t_stat, p_val = ttest_1samp(x, popmean=mu0, alternative="greater")

cohens_d = (mean - mu0) / np.std(x, ddof=1)
if   abs(cohens_d) < 0.2: d_label = "negligible"
elif abs(cohens_d) < 0.5: d_label = "small"
elif abs(cohens_d) < 0.8: d_label = "medium"
else:                     d_label = "large"

print(f"H0: true mean ≤ ₹{mu0:,.0f}")
print(f"t-statistic : {t_stat:.4f}")
print(f"p-value     : {p_val:.3e}   → "
      f"{'reject H0' if p_val < 0.05 else 'fail to reject H0'}")
print(f"Cohen's d   : {cohens_d:.3f}   → {d_label} practical effect")

# =============================================================
# STEP 11 — MONTE CARLO SIMULATION
# =============================================================
print("\n" + "=" * 60)
print("STEP 11 — MONTE CARLO (monthly revenue)")
print("=" * 60)
n_orders_month = 600
target         = 800_000
n_sims         = 10_000

sim_revenue = np.empty(n_sims)
for i in range(n_sims):
    sim_revenue[i] = np.random.choice(x, size=n_orders_month,
                                      replace=True).sum()

p_hit_target = (sim_revenue >= target).mean() * 100
p_below_700k = (sim_revenue < 700_000).mean() * 100

print(f"Simulated monthly revenue (mean) : ₹{sim_revenue.mean():,.0f}")
print(f"5th–95th percentile range        : "
      f"[₹{np.percentile(sim_revenue, 5):,.0f}, "
      f"₹{np.percentile(sim_revenue, 95):,.0f}]")
n_short = int((sim_revenue < target).sum())
print(f"P(revenue ≥ ₹{target:,.0f})         : {p_hit_target:.2f}%")
print(f"Months below target              : {n_short} of {n_sims:,}  (worst month ₹{sim_revenue.min():,.0f})")
print(f"P(revenue < ₹700,000)            : {p_below_700k:.1f}%")

fig, ax = plt.subplots(figsize=(9, 5))
sns.histplot(sim_revenue, bins=60, color="#64B5CD",
             edgecolor="white", ax=ax)
ax.axvline(target, color="red", ls="--", label=f"Target ₹{target:,.0f}")
ax.set_title("Monte Carlo Simulation — Monthly Revenue")
ax.set_xlabel("Simulated Monthly Revenue (₹)")
ax.legend()
plt.tight_layout(); plt.savefig("fig_montecarlo.png", dpi=120); plt.close()

# ---- Step 11b — sensitivity to order count ----
print("\n--- Monte Carlo sensitivity to orders per month ---")
print(f"Break-even orders at mean AOV : {math.ceil(target / mean)}  ({target / mean:.1f}, rounded up)")
np.random.seed(7)
for n_orders in (450, 500, 550, 600):
    sim = np.array([
        np.random.choice(x, n_orders, replace=True).sum()
        for _ in range(10_000)
    ])
    print(f"  {n_orders} orders: mean ₹{sim.mean():,.0f}, "
          f"P(≥ target) = {(sim >= target).mean() * 100:.1f}%")

print(f"\nIf the mean-vs-₹1,350 gap were real: "
      f"₹{(mean - 1350) * 600:,.0f} per month at 600 orders")

# =============================================================
# SUMMARY
# =============================================================
print("\n" + "=" * 60)
print("SUMMARY")
print("=" * 60)
summary = {
    "rows_after_cleaning":     len(x),
    "mean_order_value":        round(float(mean), 2),
    "median_order_value":      round(float(median), 2),
    "mode":                    float(desc["Mode"]),
    "std":                     round(float(np.std(x, ddof=1)), 2),
    "skewness":                round(float(sk), 3),
    "excess_kurtosis":         round(float(ku), 3),
    "mad":                     round(float(mad), 2),
    "iqr":                     round(float(iqr), 2),
    "q1":                      round(float(q1), 2),
    "q3":                      round(float(q3), 2),
    "trimmed_mean_10pct":      round(float(trimmed), 2),
    "cv_pct":                  round(float(cv), 1),
    "shapiro_p":               float(f"{sw_p:.3e}"),
    "yeojohnson_lambda":       round(float(lam), 3),
    "skewness_after_yj":       round(float(skew(x_yj)), 3),
    "shapiro_p_after_yj":      round(float(sw_yj_p), 4),
    "ci_95_mean":              [round(float(ci_lo), 2), round(float(ci_hi), 2)],
    "bootstrap_ci_median":     [round(float(boot_lo), 2), round(float(boot_hi), 2)],
    "t_stat":                  round(float(t_stat), 4),
    "p_value":                 float(f"{p_val:.3e}"),
    "cohens_d":                round(float(cohens_d), 3),
    "cohens_d_label":          d_label,
    "pct_orders_under_2000":   round(float(pct_under_2000), 1),
    "robust_z_outliers":       int(outlier_mask.sum()),
    "robust_z_upper":          round(float(robust_z_upper), 2),
    "tukey_fence":             round(float(fence), 2),
    "orders_beyond_fence":     int((x > fence).sum()),
    "share_below_mean_pct":    round(float((x < mean).mean() * 100), 1),
    "orders_equal_median":     int((x == median).sum()),
    "orders_above_10k":        int((x > 10000).sum()),
    "max_over_median":         round(float(x.max() / median), 2),
    "top10pct_revenue_share":  round(float(xs_desc[:int(n * 0.10)].sum()
                                          / xs_desc.sum() * 100), 1),
    "top20pct_revenue_share":  round(float(xs_desc[:int(n * 0.20)].sum()
                                          / xs_desc.sum() * 100), 1),
    "mc_p_hit_target_pct":     round(float(p_hit_target), 2),
    "mc_months_below_target":  n_short,
    "mc_p_below_700k_pct":     round(float(p_below_700k), 1),
}
with open("summary.json", "w") as f:
    json.dump(summary, f, indent=2)
print(json.dumps(summary, indent=2))
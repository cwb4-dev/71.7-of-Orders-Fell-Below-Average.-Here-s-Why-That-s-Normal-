# generate_data.py
# -------------------------------------------------------------
# Creates a synthetic e-commerce dataset with a heavy right skew.
# Reproducible with np.random.seed(42). Output: order_amounts_raw.csv
# -------------------------------------------------------------
import numpy as np
import pandas as pd

np.random.seed(42)

n_typical = 880
n_premium = 120

typical = np.random.lognormal(mean=np.log(1000), sigma=0.55, size=n_typical)
premium = np.random.lognormal(mean=np.log(3500), sigma=0.60, size=n_premium)

amounts = np.concatenate([typical, premium])
np.random.shuffle(amounts)
amounts = np.round(amounts, 2)

df = pd.DataFrame({
    "Order_ID": [f"ORD{str(i).zfill(4)}" for i in range(1, 1001)],
    "Order_Amount": amounts,
})

# ---- Inject deliberate data-quality issues ----
# (a) 3 missing values
missing_idx = np.random.choice(df.index, size=3, replace=False)
df.loc[missing_idx, "Order_Amount"] = np.nan

# (b) 1 negative value — a refund mistakenly entered as a sale
neg_idx = df[df["Order_Amount"].notna()].sample(1, random_state=42).index[0]
df.loc[neg_idx, "Order_Amount"] = -500.00

# (c) 2 duplicate rows
dupes = df.sample(2, random_state=7)
df = pd.concat([df, dupes], ignore_index=True)

df.to_csv("order_amounts_raw.csv", index=False)
print(f"Saved {len(df)} rows to order_amounts_raw.csv")
print(df.head())